"""
Test the exposer base class.

2024
"""
__author__ = "Josh Reed"

# Local code

# Other libs

# Base python
